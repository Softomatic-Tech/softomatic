# Changelog

## 1.0.0 - 2016-10-29

- Spark 3.0 compatibility
- Publishing views
